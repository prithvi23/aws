 var externalAuthUser = {
    	"fullName" : '',
    	"userName" : '',
    	"dateOfBirth" : '',
    	"accessToken": '',
    	reset : function(){
    		this.fullName = '';
    		this.userName = '';
    		this.dateOfBirth = '';
    		this.accessToken = '';
    	}
    };
